// src/Component/Sidebar.js
import React from 'react';
import { Drawer, List, ListItem, ListItemIcon, ListItemText, Typography, Box } from '@mui/material';
import { styled } from '@mui/system';
import { Link, useLocation } from 'react-router-dom';  // Import useLocation to get current path
import { 
  Dashboard, 
  CalendarToday, 
  People, 
  Message, 
  Payment, 
  Settings 
} from '@mui/icons-material';
import Logoo from "../assets/NirmiteeLogo.jpg"; 

const drawerWidth = 240;

const StyledDrawer = styled(Drawer)({
  width: drawerWidth,
  flexShrink: 0,
  '& .MuiDrawer-paper': {
    width: drawerWidth,
    boxSizing: 'border-box',
    backgroundColor: '#fff',
  },
});

const Logo = styled(Typography)({
  fontWeight: 'bold',
  color: '#29B6F6',
  fontSize: '24px',
  padding: '16px',
});

const menuItems = [
  { text: 'Overview', icon: <Dashboard />, path: '/overview' },
  { text: 'Calendar', icon: <CalendarToday />, path: '/calendar' },
  { text: 'Patient List', icon: <People />, path: '/patients' },
  { text: 'Messages', icon: <Message />, path: '/messages' },
  { text: 'Payment information', icon: <Payment />, path: '/payment-info' },
  { text: 'Settings', icon: <Settings />, path: '/settings' },
];

const Sidebar = () => {
  const location = useLocation();  

  return (
    <StyledDrawer variant="permanent" anchor="left">
      <Box sx={{ display: 'flex', alignItems: 'center', padding: '16px' }}>
        <Logo> <img src={Logoo} alt="Logo" style={{ width: 200, height: 'auto', marginBottom: 16 }} /></Logo>
        <Typography variant="caption" sx={{ marginLeft: '8px', color: '#757575' }}>
        </Typography>
      </Box>
      <List>
        {menuItems.map((item, index) => (
          <ListItem 
            button 
            key={item.text} 
            component={Link} 
            to={item.path}  
            selected={location.pathname === item.path}  
            sx={{ textDecoration: 'none' }}  
          >
            <ListItemIcon sx={{ color: location.pathname === item.path ? '#29B6F6' : 'inherit' }}>
              {item.icon}
            </ListItemIcon>
            <ListItemText 
              primary={item.text} 
              sx={{ 
                '& .MuiListItemText-primary': { 
                  color: location.pathname === item.path ? '#29B6F6' : 'inherit',
                  fontWeight: location.pathname === item.path ? 'bold' : 'normal',
                }
              }} 
            />
          </ListItem>
        ))}
      </List>
    </StyledDrawer>
  );
};

export default Sidebar;