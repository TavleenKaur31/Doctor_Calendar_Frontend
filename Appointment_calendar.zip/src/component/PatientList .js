// PatientList.js
import React, { useEffect, useState } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from '@mui/material';
import axios from 'axios';
import base_url from '../api/bootapi';

const PatientList = () => {
  const [appointments, setAppointments] = useState([]);

  useEffect(() => {
    // Fetch appointment data from the API
    axios.get(`${base_url}/api/appointments`)
      .then(response => {
        const data = Array.isArray(response.data) ? response.data : [response.data];
        setAppointments(data);
      })
      .catch(error => console.error('Error fetching appointments:', error));
  }, []);

  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Time</TableCell>
            <TableCell>Name</TableCell>
            <TableCell>Title</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {appointments.map((appointment) => (
            <TableRow key={appointment.id}>
          <TableCell>
      {new Date(appointment.appointmentDateAndTime).toLocaleString('en-US', {
        weekday: 'long', // Day of the week (e.g., Monday)
        year: 'numeric',
        month: 'long', // Month (e.g., September)
        day: 'numeric', // Day of the month
        hour: 'numeric',
        minute: 'numeric',
        second: 'numeric',
        hour12: true // 12-hour time format with AM/PM
      })}
    </TableCell>
              <TableCell>{appointment.name}</TableCell>
              <TableCell>{appointment.title}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default PatientList;
